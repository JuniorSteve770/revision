// src/projects/Project2/pages/Page1.js
import React from 'react';

const Page1 = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Contenu de la Page 1 de Projet 2</h2>
      <p>Ceci est la première page du projet 2.</p>
    </div>
  );
};

export default Page1;