// src/projects/Project1/pages/Page3.js
import React from 'react';

const Page3 = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Contenu de la Page 2 de Projet 1</h2>
      <p>Ceci est la deuxième page du projet 1.</p>
    </div>
  );
};

export default Page3;